import io.qameta.allure.junit4.DisplayName;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import model.ResponseUserData;
import model.User;
import model.UserApi;
import model.UserData;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpStatus;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static model.Constants.BASE_URI;
import static org.hamcrest.CoreMatchers.is;

public class ChangingUserDataTest {
    protected String email;
    protected String password;
    protected String name;
    protected String accessToken;
    protected UserApi userApi;

    @Before
    public void setUp() {
        RestAssured.baseURI = BASE_URI;
        userApi = new UserApi();
        email = "Leo" + RandomStringUtils.randomNumeric(3) + "@yandex.ru";
        password = "pass" + RandomStringUtils.randomNumeric(4);
        name = "User" + RandomStringUtils.randomNumeric(4);
        UserData userData = new UserData(email, password, name);
        Response response = userApi.createUser(userData);
        accessToken = response.body().as(ResponseUserData.class).getAccessToken();
    }

    @After
    public void closeUp() {
        userApi.deleteUser(accessToken);
    }

    @Test
    @DisplayName("Изменение данных рользователя с авторизацией")
    public void changingUserDataWithAuthTest() {
        //Авторизация пользователя
        UserData userData = new UserData(email, password);
        Response response = userApi.loginUser(userData);
        accessToken = response.body().as(ResponseUserData.class).getAccessToken();
        //Изменение данных пользователя
        UserData newUserData = new UserData("i"+email, password+"1", name+"5");
        Response newResponse = userApi.changingUser(newUserData, accessToken);
        newResponse.then().assertThat().log().all()
                .statusCode(HttpStatus.SC_OK)
                .body("success", is(true));
        String newEmail = newResponse.body().as(ResponseUserData.class).getUser().getEmail();
        System.out.println("Новый email:   " + newEmail);
    }
}
